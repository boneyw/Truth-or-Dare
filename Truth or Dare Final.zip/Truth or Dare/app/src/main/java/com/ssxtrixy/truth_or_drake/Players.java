package com.ssxtrixy.truth_or_drake;

import android.app.Application;


public class Players extends Application {


    private String _Name;
    private String _Name2;
    private int turn = 1;

    //Create a sinengon port for player so it stay the same
    private static Players instance;

    //Make so I cant create multiple instance by a mistake
    private Players() {

    }

    public static Players getInstance() {
        if (instance == null) {
            instance = new Players();
        }
        return instance;
    }
    //Setter and Getter for infomation going in to the database


    public int getTurn() {

        return turn;
    }

    public void setTurn(int turn) {

        this.turn = turn;
    }

    public String get_Name() {

        return _Name;
    }

    public void set_Name(String _Name) {

        this._Name = _Name;
    }

    public String get_Name2() {

        return _Name2;
    }

    public void set_Name2(String _Name2) {

        this._Name2 = _Name2;
    }

    //Who is giving the truth or dare
    public String pickPlayer() {



        if (turn ==1) {
            return get_Name();
        } else {

            return get_Name2();
        }
    }
    //Who doing to the thruth or dare
    public String actionPlayer() {



        if (turn == 1) {
            return get_Name2();
        } else {

            return get_Name();

        }

    }

}
