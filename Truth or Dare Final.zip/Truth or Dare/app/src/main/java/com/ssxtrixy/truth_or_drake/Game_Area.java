package com.ssxtrixy.truth_or_drake;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Game_Area extends AppCompatActivity {

    private Button btntruth;
    private Button btndare;
    private TextView  txtplayer;
    private Players players;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game__area);

        players =Players.getInstance();

        txtplayer = (TextView) findViewById(R.id.txtplayername);
        txtplayer.setText(players.actionPlayer());


        btntruth = findViewById(R.id.btnTruth);
        btntruth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                    opentruth();
            }

        });

        btndare = findViewById(R.id.btnDare);
        btndare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                opendare();
            }

        });

    }

    public void opentruth() {
        Intent intent = new Intent(this, Truth.class);
        startActivity(intent);
    }

    public void opendare() {
        Intent intent = new Intent(this, Dare.class);
        startActivity(intent);
    }

}
