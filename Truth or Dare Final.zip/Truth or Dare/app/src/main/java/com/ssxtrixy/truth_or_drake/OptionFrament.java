package com.ssxtrixy.truth_or_drake;


import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.RelativeLayout;
import android.widget.Switch;

public class OptionFrament extends Fragment {
    private Switch color;
    private RelativeLayout layout;
    public static final String PREFS_NAME = "MyPrefsFile";

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.fragment_option, container,false);


        color = (Switch) view.findViewById(R.id.color);
        layout = (RelativeLayout) view.findViewById(R.id.TorD);

        // Set the Color of the App
        color.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                //Checked the switch button to change the color
                if(isChecked ==true){
                    layout.setBackgroundColor(Color.RED);
                }
                else {
                    layout.setBackgroundColor(Color.GRAY);
                }
            }
        });


        return view;
    }


}

