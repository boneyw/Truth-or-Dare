package com.ssxtrixy.truth_or_drake;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Dare extends AppCompatActivity {

    private TextView txtdare2;
    private Button create;
    private TextView time;
    private TextView txtdare1;
    private EditText createEdit;
    String  textDare1;
    public static final String EXTRA_IS_BUTTON_ONE = "isButtonOne";
    private Players players;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dare);

        txtdare2 = (TextView) findViewById(R.id.txtdare2);
        create = (Button) findViewById(R.id.btncreate);
        time = (TextView) findViewById(R.id.txttime);
        txtdare1 = (TextView) findViewById(R.id.txtdare1);
        createEdit = (EditText)findViewById(R.id.txtwritedare);

        // Instance of the of the claas to get player name
        players =Players.getInstance();
        time.setText(players.pickPlayer());

        // Store text for home screen
        txtdare1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(Dare.this, MainActivity.class);
                textDare1 = txtdare1.getText().toString();
                // Store text so it used in the next class
                i.putExtra("Value", textDare1);
                // Used to check for the button click on anther actaivity
                i.putExtra("isButtonOne", true);
                startActivity(i );
            }

        });
        create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(Dare.this, MainActivity.class);
                textDare1 = createEdit.getText().toString();
                i.putExtra("Value", textDare1);
                i.putExtra("isButtonOne", true);
                startActivity(i );
            }

        });
        txtdare2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent i = new Intent(Dare.this, MainActivity.class);
                textDare1 = txtdare2.getText().toString();
                i.putExtra("Value", textDare1);
                i.putExtra("isButtonOne", true);
                startActivity(i );
            }
        });
    }
}

