package com.ssxtrixy.truth_or_drake;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Truth extends AppCompatActivity {

    private Button create;
    private TextView time;
    String  textDare1;
    public static final String EXTRA_IS_BUTTON_ONE = "isButtonOne";
    private Players players;
    private EditText createEdit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_truth);

        create = (Button) findViewById(R.id.btncreate);
        time = (TextView) findViewById(R.id.txttime);
        createEdit = (EditText)findViewById(R.id.createtruth);
        // Instance of the of the claas to get player name
        players =Players.getInstance();
        time.setText(players.pickPlayer());

        create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(Truth.this, MainActivity.class);
                textDare1 = createEdit.getText().toString();
                // Store text so it used in the next class
                i.putExtra("Value", textDare1);
                // Used to check for the button click on anther actaivity
                i.putExtra("isButtonOne", true);

                startActivity(i );;
            }

        });


    }

}
