package com.ssxtrixy.truth_or_drake;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class C_Player extends AppCompatActivity {
    private Button btnDone;

    private EditText txtBox1;
    private EditText txtBox2;
    public String playerone;
    public String playertwo;
    private Players players

    ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_c__player2);
        players = Players.getInstance();

        btnDone = (Button) findViewById(R.id.btnDone);
        txtBox1=(EditText) findViewById(R.id.Box1);
        txtBox2=(EditText) findViewById(R.id.Box2);

        playerone = txtBox1.getText().toString();
        playertwo = txtBox2.getText().toString();

        txtBox1.addTextChangedListener(checkField);
        txtBox2.addTextChangedListener(checkField);

        btnDone.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                playerone = txtBox1.getText().toString();
                playertwo = txtBox2.getText().toString();

                players.set_Name(playerone);
                players.set_Name2(playertwo);

               openGame_Area();
            }
        });


    }
    //Checking for text in the username
    private TextWatcher checkField = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }
        // Enable button id the text is in the two boxes
        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            String player1 = txtBox1.getText().toString().trim();
            String player2 = txtBox2.getText().toString().trim();
            btnDone.setEnabled(!player1.isEmpty() && !player2.isEmpty());

        }

        @Override
        public void afterTextChanged(Editable s) {

        }
    };

    public void openGame_Area() {
        Intent intent = new Intent(this, Game_Area.class);
        startActivity(intent);
    }
}
