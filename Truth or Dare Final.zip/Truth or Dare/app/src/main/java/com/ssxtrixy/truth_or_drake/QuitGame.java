package com.ssxtrixy.truth_or_drake;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class QuitGame extends AppCompatActivity implements View.OnClickListener {
    private Button yes;
    private Button no;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quit_game);

        yes = (Button) findViewById(R.id.btnyes);
        no = (Button) findViewById(R.id.btnno);

        yes.setOnClickListener(this);
        no.setOnClickListener(this);

}
    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnyes:
                openWinner();
                break;
            case R.id.btnno:
                //Go back to the last screen
                super.onBackPressed();
                break;
        }
    }
    public void openWinner() {
        Intent intent = new Intent(this, Winner.class);
        startActivity(intent);
    }
}
