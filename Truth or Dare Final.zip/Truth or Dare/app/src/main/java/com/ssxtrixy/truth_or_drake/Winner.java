package com.ssxtrixy.truth_or_drake;


import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;


public class Winner extends AppCompatActivity {

    private Players players;
    private TextView name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_winner);

        name = (TextView) findViewById(R.id.txtwonplayer);
        players = Players.getInstance();
        name.setText(players.actionPlayer());;

        // Quit Application after 10 sec
        new Handler().postDelayed(new Runnable(){
            @Override
            public void run() {
                Intent intent = getBaseContext().getPackageManager()
                        .getLaunchIntentForPackage(getBaseContext().getPackageName());
                intent .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);

            }
        }, 10000);

    }

}
