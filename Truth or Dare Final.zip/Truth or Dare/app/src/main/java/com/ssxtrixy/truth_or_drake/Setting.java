package com.ssxtrixy.truth_or_drake;

public class Setting {
}
