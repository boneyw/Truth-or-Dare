
/*------------William Boney-------------------
--------------Truth Or Dare-------------------
----------------12/16/18----------------------
Thank you for playing my game I hope you enjoy it
 */

package com.ssxtrixy.truth_or_drake;


import android.content.Intent;
import android.net.Uri;
import android.os.CountDownTimer;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;


public class MainActivity extends AppCompatActivity {

    int change =1;
    String  textDare1;
    private Button btngame;
    private Button btnquit;
    private Button complete;
    public TextView mDare;
    public TextView time;
    private TextView name;
    private Players players;
    private long timeEnd;
    private long timeLeft =millTimeLeft;
    private  boolean timeRunning;
    private CountDownTimer countDownTimer;
    private static long millTimeLeft= 1800000; //30min
    public static final String EXTRA_IS_BUTTON_ONE = "isButtonOne";
    static final int REQUEST_VIDEO = 101;
    private Uri videoUri =null;






    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        players =Players.getInstance();
        mDare =  (TextView)findViewById(R.id.txttruthordare);
        time =  (TextView)findViewById(R.id.txttime);
        name = (TextView) findViewById(R.id.txtname);
        mDare.setText(getIntent().getStringExtra("Value"));
        btngame = (Button) findViewById(R.id.btngame);
        btnquit = (Button) findViewById(R.id.btnquit);
        complete = (Button) findViewById(R.id.btncomplete);

        // In take info from anther class to use to set data
       boolean isButtonOne = getIntent().getBooleanExtra(EXTRA_IS_BUTTON_ONE,false);

        // In take info from anther class to use to set data
        mDare.setText(getIntent().getStringExtra("Value"));


        // Disable and enable the two button
        if (isButtonOne == true)
        {
            btngame.setEnabled(false);
            startStop();
            complete.setEnabled(true);
            name.setText(players.actionPlayer());


        }
        else {
            btngame.setEnabled(true);

        }
        //Change who turn it is
        if(players.getTurn() == 1) {
            players.setTurn(2);

        }
        else {
            players.setTurn(1);

        }
        //Navigation bar setup
        BottomNavigationView bottomNav = findViewById(R.id.switch_bar);
        bottomNav.setOnNavigationItemSelectedListener(navlistener);

        // Start the fragment
        getSupportFragmentManager().beginTransaction().replace(R.id.Frame_bar,
               new HomeFrament()).commit();
        btngame.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                openPlayerSelection();

            }
        });

        complete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openGameArea();
                Toast.makeText(getBaseContext(), "You can see video in Gallary", Toast.LENGTH_LONG).show();
                Intent takeVideoIntent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
                if (takeVideoIntent.resolveActivity(getPackageManager()) != null) {
                    startActivityForResult(takeVideoIntent, REQUEST_VIDEO);
                }
            }
        });
        btnquit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                openActivity_quit_game();
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
        if (requestCode == REQUEST_VIDEO && resultCode == RESULT_OK) {
            videoUri = intent.getData();
        }
    }

    // Opening ofter classes with buttons
    public void openPlayerSelection(){
        Intent intent = new Intent(this, C_Player.class);
        startActivity(intent);
    }
    public void openActivity_quit_game(){
        Intent intent = new Intent(this, QuitGame.class);
        startActivity(intent);
    }
    public void openGameArea(){
        Intent intent = new Intent(this, Game_Area.class);
        startActivity(intent);
    }

    private BottomNavigationView.OnNavigationItemSelectedListener navlistener =
            new BottomNavigationView.OnNavigationItemSelectedListener() {
                @Override
                //Change the fragment you are looking at
                public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                    Fragment selectFragement = null;
                    // Home icon
                    switch (menuItem.getItemId()) {
                        case R.id.switch_home:
                            selectFragement = new HomeFrament();
                            break;
                            //Rules icon
                        case R.id.switch_rules:
                            selectFragement = new RulesFrament();
                            break;
                            //Option icon
                        case R.id.switch_option:
                            selectFragement = new OptionFrament();
                            break;

                    }
                    // Start the menu layout
                    getSupportFragmentManager().beginTransaction().replace(R.id.Frame_bar,
                            selectFragement).commit();
                    return true;
                }
    };

    public void openWinner() {
        Intent intent = new Intent(this, Winner.class);
        startActivity(intent);
    }

    // Start the time and stop it when time
    public void startStop(){
        if (textDare1 != null){
            stopTime();
        }
        else {
            startTime();
        }
    }

    //start timer
    public void startTime(){
        timeEnd = System.currentTimeMillis() + millTimeLeft;
        countDownTimer = new CountDownTimer(timeLeft,1000) {
            @Override
            public void onTick(long timeDone) {
                timeLeft =timeDone;
                updateTimer();

            }

            @Override
            public void onFinish() {
                Intent intent = new Intent(MainActivity.this, Winner.class);
                startActivity(intent);

            }
        }.start();

        timeRunning = true;

    }
    //Stop timer
    public void stopTime(){
        countDownTimer.cancel();
        timeRunning= false;


    }
    // Update the time to change when it suppose to
    public void updateTimer(){
        int min = (int) (timeLeft /1000) /60;
        int sec = (int) (timeLeft /1000) % 60;

        String timeLeftOnClock;

        timeLeftOnClock = String.format(Locale.getDefault() , "%02d:%02d" , min, sec);


        time.setText(timeLeftOnClock);
    }
    // Save time to keep Running if you hit back
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putLong("Milltime",timeLeft);
        outState.putBoolean("timerunning", timeRunning);
        outState.putLong("endtime", timeEnd);


    }
    // Show the update time whe you leave the app
    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);

        timeLeft= savedInstanceState.getLong("Milltime");
        timeRunning = savedInstanceState.getBoolean("timerunning");
        updateTimer();

        if(timeRunning){
            timeEnd = savedInstanceState.getLong("endTime");
            millTimeLeft =timeEnd - System.currentTimeMillis();
            startTime();
        }
    }

}

